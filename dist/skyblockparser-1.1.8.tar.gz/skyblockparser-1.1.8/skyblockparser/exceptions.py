class SkyblockParserException(Exception):
    pass